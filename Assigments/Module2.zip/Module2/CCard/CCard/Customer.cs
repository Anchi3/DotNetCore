﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace CCard
{
    public class Customer
    {
        public string Name { set; get; }
        public string CreditCard { set; get; }
        public string Password { get; set; }


    }

 
}
