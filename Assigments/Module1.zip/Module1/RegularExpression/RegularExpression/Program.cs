﻿using System;
using System.Numerics;
using System.Text.RegularExpressions;

namespace RegularExpression
{
    class Program
    {


        static void Main(string[] args)
        {

            BigInteger bi = new BigInteger();



            /* ConsoleKeyInfo cki = Console.ReadKey();

              if(cki.Key == ConsoleKey.Enter)
              {
                  Console.WriteLine("Enter key has been pressed");

              }
              else if(cki.Key == ConsoleKey.Escape)
              {
                  Console.WriteLine("Escape key has been pressed");
              }
            

            string pn1 = "204 123-4567";
            string pn2 = "204 223-4567";
            string pn3 = "204 323-4567";
            string pn4 = "204 423-4567";
                        //ddd ddd-dddd pattern

            string email1 = "rolante@abc.com";
            //lllllll@lll.lll pattern

            // @ - verbatim
            string path = @"c:\program\data\file.exe";

            string pattern = @"\ba\b"; // \b - word boundary
            string inputString = "b";

            Console.WriteLine(Regex.IsMatch(pattern, inputString)); // true 

            Regex re = new Regex(@"^bbb$"); // ^ - beginning of pattern, $ - end of pattern
            inputString = "bbb";
            Console.WriteLine(re.IsMatch(inputString));

            Regex rr = new Regex(@"^b{3} b{3}-b{4}$"); // {3} = 3 times input in regex
            string input = "bbb bbb-bbbb";
            Console.WriteLine(rr.IsMatch(input));

            Regex rrr = new Regex(@"^\d{3} \d{3}-\d{4}$"); // \d = digit
            string input2 = "204 999-9876";
            Console.WriteLine(rrr.IsMatch(input2));


            PrintIsMatch("204 999-9876", @"^\d{3} \d{3}-\d{4}$");
            PrintIsMatch("BooK", @"[a-zA-Z]{4}"); // [a-zA-Z] - a-z,  space, \- hyphen --- list of symbols... {4} - number of characters
            PrintIsMatch("cat", @"[a-z]{3,}"); // {3,} - three or more characters  
            PrintIsMatch("cat9s", @"[a-z 0-9]{3,5}"); // {3,5} - three to five characters 
            PrintIsMatch("Duane_Cruz", @"\w{5,32}"); // \w = [a-zA-Z0-9_]
            PrintIsMatch("      ", @"\s{5,10}"); // \s = white space
            PrintIsMatch("a", @"[a-z]+"); // + = {1,} shortcut
            PrintIsMatch("at", @"c?at"); // ? - {0,1} characters
            PrintIsMatch("ccc*cccat", @"c*at"); // * - {0,}
            PrintIsMatch("c*t", @"c\*at"); // \* - *
            PrintIsMatch("car", @"[^a-c]ar"); // [^] - not
            PrintIsMatch("Cake", @".{4}"); // . - any character (except whitespace)
            PrintIsMatch("gogogogogo", @"(go)+"); // () - repeating characters
            PrintIsMatch("sat", @"s(a|i)t"); // ( | ) alternating characters, sat || sit
        }

        public static void PrintIsMatch(string value, string pattern)
        {
            Regex reg = new Regex($@"^{pattern}$", RegexOptions.IgnoreCase); // IgnoreCase - removes case sensitivity
            Console.WriteLine($"{value} and {pattern}: {reg.IsMatch(value)}");
        }
            */
    }
}
